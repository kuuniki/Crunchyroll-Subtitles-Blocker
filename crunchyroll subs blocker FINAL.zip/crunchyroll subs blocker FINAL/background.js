chrome.runtime.onInstalled.addListener(() => {
  console.log("Crunchyroll Subtitles Blocker Extension Installed");
});

// Listen for messages to update the blocker state
chrome.runtime.onMessage.addListener((message) => {
  if (message.action === "updateBlockerState") {
    const { state } = message;

    // Update the blocker state in storage
    chrome.storage.sync.set({ blockerEnabled: state }, () => {
      if (state) {
        console.log("Subtitles Blocker ON");
      } else {
        console.log("Subtitles Blocker OFF");
      }
    });
  }
});

// Apply the blocking rules based on the stored state
chrome.storage.sync.get("blockerEnabled", (data) => {
  const blockerEnabled = data.blockerEnabled ?? true;
  
  if (blockerEnabled) {
    // Block subtitles by setting up the declarativeNetRequest rules
    // Assuming you've set up rules.json as mentioned before
    chrome.declarativeNetRequest.updateDynamicRules({
      addRules: [
        {
          id: 1,
          action: { type: "block" },
          condition: {
            urlFilter: "*subtitles-octopus-worker.js*",
            resourceTypes: ["script"]
          }
        },
        {
          id: 2,
          action: { type: "block" },
          condition: {
            urlFilter: "*subtitles-octopus-worker.data*",
            resourceTypes: ["xmlhttprequest"]
          }
        },
        // Add more blocking rules here as necessary
      ]
    });
  } else {
    // Disable blocking by clearing the rules
    chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1, 2] // The rule IDs to remove
    });
  }
});
