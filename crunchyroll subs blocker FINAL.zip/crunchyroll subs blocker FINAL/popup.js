// Get elements
const toggleButton = document.getElementById("toggleButton");
const statusText = document.getElementById("status");

// Initialize the popup with the correct state
chrome.storage.sync.get("blockerEnabled", (data) => {
  const blockerEnabled = data.blockerEnabled ?? true;
  updateUI(blockerEnabled);
});

// Update UI text and button based on blocker state
function updateUI(isEnabled) {
  if (isEnabled) {
    toggleButton.textContent = "Turn Blocker Off";
    statusText.textContent = "Blocker is currently ON.";
  } else {
    toggleButton.textContent = "Turn Blocker On";
    statusText.textContent = "Blocker is currently OFF.";
  }
}

// Add event listener for the button
toggleButton.addEventListener("click", () => {
  chrome.storage.sync.get("blockerEnabled", (data) => {
    const newState = !(data.blockerEnabled ?? true);
    chrome.storage.sync.set({ blockerEnabled: newState }, () => {
      updateUI(newState);
      chrome.runtime.sendMessage({ action: "updateBlockerState", state: newState });
    });
  });
});
