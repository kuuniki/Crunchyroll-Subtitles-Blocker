// content.js

(function() {
    // Block subtitle-related functions if they exist
    window.addEventListener('load', () => {
        const originalFunction = window.subtitlesOctopus || window.subtitles; 
        if (originalFunction) {
            // Prevent subtitles from initializing
            window.subtitlesOctopus = null;
            window.subtitles = null;
        }

        // Hide subtitles after page load
        hideSubtitles();
        
        // Continuously check for subtitle elements every 100ms
        setInterval(() => {
            hideSubtitles();
        }, 100); // Check every 100ms
    });

    // Function to hide subtitle elements
    function hideSubtitles() {
        // Look for subtitle containers and hide them
        const subtitleContainers = document.querySelectorAll('.subtitlesoctopus, .subtitle-container, .cr-subtitles, .cr-subtitles-container');
        subtitleContainers.forEach(subtitle => {
            subtitle.style.display = 'none'; // Hide subtitles
        });
    }

    // Observe DOM changes and hide subtitles if added dynamically
    const observer = new MutationObserver((mutationsList) => {
        for (const mutation of mutationsList) {
            if (mutation.type === 'childList') {
                hideSubtitles(); // Hide subtitles dynamically if they are injected
            }
        }
    });

    // Start observing the body for subtitle changes
    observer.observe(document.body, { childList: true, subtree: true });
})();
